<?php
/**
 * GeneratePress child theme functions and definitions.
 *
 * Add your custom PHP in this file.
 * Only edit this file if you have direct access to it on your server (to fix errors if they happen).
 */

 //* Add Scripts for Admin onlys
function wpmd_enqueuing_admin_scripts_init(){
    wp_enqueue_style('wpmd-admin-css', get_stylesheet_directory_uri().'/inc/admin/css/admin.css');
    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('my-admin-script-handle', get_stylesheet_directory_uri()."/inc/admin/js/admin.js", array( 'wp-color-picker'), false, true);
}
add_action( 'admin_enqueue_scripts', 'wpmd_enqueuing_admin_scripts_init' );

//* Enable Shortcode in widget
add_filter( 'widget_text', 'do_shortcode' );

//* Getting PHP files from folders
require_once( get_stylesheet_directory() . '/inc/web-cpts-data.php');
require_once( get_stylesheet_directory() . '/inc/web-shortcodes-data.php');
require_once( get_stylesheet_directory() . '/inc/wpmd-theme-options.php');


/* For Developer Information--
 
   //===================== All CPTS ARE REGISTERED IN "inc/web-cpts-data.php" =====================//
   //===================== All SHORTCODES ARE REGISTERED IN "inc/web-shortcodes-data.php" =====================//
    
*/
