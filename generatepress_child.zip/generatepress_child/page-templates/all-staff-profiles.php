<?php

/* Template Name: Staff Archive */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

get_header();

?>

<main class="site-main staff-profiles-main" id="main">
<article <?php post_class(); ?> <?php generate_do_microdata( 'article' ); ?>>
    <div class="inside-article">
        <?php

        if ( generate_show_entry_header() ) :
            ?>

            <header class="entry-header">
                <?php
                /**
                 * generate_before_page_title hook.
                 *
                 * @since 2.4
                 */
                do_action( 'generate_before_page_title' );

                if ( generate_show_title() ) {
                    $params = generate_get_the_title_parameters();

                    the_title( $params['before'], $params['after'] );
                }

                /**
                 * generate_after_page_title hook.
                 *
                 * @since 2.4
                 */
                do_action( 'generate_after_page_title' );
                ?>
            </header>

            <?php
        endif;

        /**
         * generate_after_entry_header hook.
         */
        do_action( 'generate_after_entry_header' );

        $itemprop = '';

        if ( 'microdata' === generate_get_schema_type() ) {
            $itemprop = ' itemprop="text"';
        }
        ?>
        <div class="entry-content"<?php echo $itemprop; // phpcs:ignore -- No escaping needed. ?>>
            <?php
            the_content();

            $args = array(
                'post_type'      => 'staffprofile',
                'order'          => 'ASC',
                'posts_per_page' => -1,
                'post_status'    => 'publish',
                'paged'          => get_query_var( 'paged' )
            );
            $custom_query = new WP_Query( $args );

            if ( $custom_query->have_posts() ) { ?>
                <div class="staffProfiles-container">          
                    <?php while ( $custom_query->have_posts() ) {
                     $custom_query->the_post(); ?>
                    <div class="singleStaff-holder">
                        <div class="upper-Holder">
                            <div class="imgHolder">
                                <img src="<?php the_post_thumbnail_url(); ?>" alt="Profile Image">
                            </div>
                            <div class="infoHolder">
                                <span><?php echo wp_trim_words(get_the_excerpt(), 25); ?></span>
                            </div>
                        </div>
                        <div class="lower-holder">
                            <span class="staff-meta">
                                <i class="fas fa-user-circle"></i><span class="staff-nm"><?php the_title(); ?></span>
                            </span><br>
                            <a href="<?php the_permalink(); ?>" class="button">Read More</a>
                        </div>
                    </div>
                  <?php } ?>
                </div>

                <?php
                // Add pagination
                echo '<div class="pagination">';
                echo paginate_links( array(
                    'total'   => $custom_query->max_num_pages,
                    'current' => max( 1, get_query_var( 'paged' ) ),
                ) );
                echo '</div>';
                wp_reset_postdata();
            }
        
            ?>
        </div>

        <?php
        /**
         * generate_after_content hook.
         */
        do_action( 'generate_after_content' );
        ?>
        
    </div>
</article> 
</main>

<?php
generate_construct_sidebars();
get_footer();
