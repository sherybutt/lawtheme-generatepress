<?php

/* Template Name: Educational Alerts Archive */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

get_header();

?>

<main class="site-main educational-main" id="main">
<article <?php post_class(); ?> <?php generate_do_microdata( 'article' ); ?>>
    <div class="inside-article">
        <?php

        if ( generate_show_entry_header() ) :
            ?>

            <header class="entry-header">
                <?php
                /**
                 * generate_before_page_title hook.
                 *
                 * @since 2.4
                 */
                do_action( 'generate_before_page_title' );

                if ( generate_show_title() ) {
                    $params = generate_get_the_title_parameters();

                    the_title( $params['before'], $params['after'] );
                }

                /**
                 * generate_after_page_title hook.
                 *
                 * @since 2.4
                 */
                do_action( 'generate_after_page_title' );
                ?>
            </header>

            <?php
        endif;

        /**
         * generate_after_entry_header hook.
         */
        do_action( 'generate_after_entry_header' );

        $itemprop = '';

        if ( 'microdata' === generate_get_schema_type() ) {
            $itemprop = ' itemprop="text"';
        }
        ?>
        <div class="entry-content"<?php echo $itemprop; // phpcs:ignore -- No escaping needed. ?>>
            <?php
            the_content();

            $args = array(
                'post_type'      => 'ealert',
                'order'          => 'ASC',
                'posts_per_page' => 9,
                'post_status'    => 'publish',
                'paged'          => get_query_var( 'paged' )
            );
            $custom_query = new WP_Query( $args );

            if ( $custom_query->have_posts() ) { ?>
                <div class="wpmd-gcpts-container">          
                    <?php while ( $custom_query->have_posts() ) {
                     $custom_query->the_post(); ?>
                        <div class="wpmd-gsingle-cpt-holder">   
                            <div class="head-style">
                                <h2><?php echo '<a href="'.get_the_permalink().'" title="' . get_the_title() . '">' . get_the_title() . '</a>' ; ?></h2>
                            </div>
                            <div class="wpmd-gcontent">
                                <?php
                                $excerpt = get_the_excerpt();
                                    echo '<p>'.wp_trim_words($excerpt, 250).'</p>';
                                ?>
                            </div>
                        </div>
                  <?php } ?>
                </div>

                <?php
                // Add pagination
                echo '<div class="pagination">';
                echo paginate_links( array(
                    'total'   => $custom_query->max_num_pages,
                    'current' => max( 1, get_query_var( 'paged' ) ),
                ) );
                echo '</div>';
                wp_reset_postdata();
            }
        
            ?>
        </div>

        <?php
        /**
         * generate_after_content hook.
         */
        do_action( 'generate_after_content' );
        ?>
        
    </div>
</article> 
</main>

<?php
generate_construct_sidebars();
get_footer();
