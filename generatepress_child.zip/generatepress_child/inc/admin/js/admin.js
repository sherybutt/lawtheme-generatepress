jQuery(document).ready(function($){
    //To make simple input feild into WP COLOR PICKER 
    $('.my-colorpicker-field').wpColorPicker();
});s